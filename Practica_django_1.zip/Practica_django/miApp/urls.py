from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('productos/', views.productos, name='productos'),
    # path('', views.Bienvenida, name='Bienvenida'),
    # path('BienvenidaProductos/', views.BienvenidaProductos, name='BienvenidaProductos'),
    path('productos/ProductosDetalle/<int:codigoProducto>', views.ProductosDetalle, name='ProductosDetalle'),
    # path('Contacto/', views.formProductos, name='Contacto'),
    path('pruebas/', views.pruebas, name = 'pruebas'),
]